package application.teste;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MainTeste {

	@Test
	void testStart() {
		
	}

	@Test
	void testMain() {
		
	}

}
