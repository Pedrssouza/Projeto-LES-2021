package model;

import java.sql.Date;

public class Exame {
	
	private long id;
	private String nomeExame;
	private String dia;
	private String hora;
	
	public Exame() {
		
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getNomeExame() {
		return nomeExame;
	}


	public void setNomeExame(String nomeExame) {
		this.nomeExame = nomeExame;
	}


	public String getDia() {
		return dia;
	}


	public void setDia(String dia) {
		this.dia = dia;
	}


	public String getHora() {
		return hora;
	}


	public void setHora(String hora) {
		this.hora = hora;
	}


	@Override
	public String toString() {
		return "Exame [id=" + id + ", nomeExame=" + nomeExame + ", dia=" + dia + ", hora=" + hora + "]";
	}
	
}
