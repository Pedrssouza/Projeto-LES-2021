package model.teste;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ExameTeste {

	@Test
	void testExame() {
	}

	@Test
	void testGetId() {
	}

	@Test
	void testSetId() {
	}

	@Test
	void testGetNomeExame() {
	}

	@Test
	void testSetNomeExame() {
	}

	@Test
	void testGetDia() {
		
	}

	@Test
	void testSetDia() {
		
	}

	@Test
	void testGetHora() {
		
	}

	@Test
	void testSetHora() {
		
	}

	@Test
	void testToString() {
		
	}

}
