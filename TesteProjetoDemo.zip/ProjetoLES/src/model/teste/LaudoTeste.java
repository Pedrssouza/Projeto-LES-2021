package model.teste;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class LaudoTeste {

	private Object paciente;
	private Object data;
	private Object medico;
	private Object resultado;

	@Test
	void testLaudo() {
		
	}

	@Test
	void testGetPaciente() {
		
	}

	@Test
	void testSetPaciente() {
		
		this.paciente = paciente;
	}

	@Test
	void testGetData() {
		
	}

	@Test
	void testSetData() {
		this.data = data;
	}

	@Test
	void testGetMedico() {
		
	}

	@Test
	void testSetMedico() {
		this.medico = medico;
	}

	@Test
	void testGetResultado() {
		
	}

	@Test
	void testSetResultado() {
		this.resultado = resultado;
	}

	@Test
	void testToString() {
	}

}
