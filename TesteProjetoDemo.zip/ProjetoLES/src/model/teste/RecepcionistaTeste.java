package model.teste;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RecepcionistaTeste {

	

	private Object id;
	private Object nome;
	private Object cpf;
	private Object email;
	private Object endereco;

	@Test
	void testRecepcionista() {
		
	}

	@Test
	void testGetId() {
		
	}

	@Test
	void testSetId() {
		this.id = id;
	}

	@Test
	void testGetNome() {
		
	}

	@Test
	void testSetNome() {
		this.nome = nome;
	}

	@Test
	void testGetCpf() {
		
	}

	@Test
	void testSetCpf() {
		this.cpf = cpf;
	}

	@Test
	void testGetEmail() {
		
	}

	@Test
	void testSetEmail() {
		this.email = email;
	}

	@Test
	void testGetEndereco() {
		
	}

	@Test
	void testSetEndereco() {
		this.endereco = endereco;
	}

	@Test
	void testToString() {
		
	}

}
