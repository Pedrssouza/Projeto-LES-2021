package model.teste;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MedicoTeste {

	private Object id;
	private Object nome;
	private Object crm;

	@Test
	void testMedico() {
		
	}

	@Test
	void testGetId() {
		
	}

	@Test
	void testSetId() {
		this.id = id;
	}

	@Test
	void testGetNome() {
		
	}

	@Test
	void testSetNome() {
		this.nome = nome;
	}

	@Test
	void testGetCrm() {
		
	}

	@Test
	void testSetCrm() {
		this.crm = crm;
	}

	@Test
	void testToString() {
		
	}

}
