package model.teste;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ProfessorTeste {
	private Object id;
	private Object nome;
	private Object crm;

	@Test
	void testProfessor() {
	}

	@Test
	void testSetId() {
		this.id = id;
	}

	@Test
	void testSetNome() {
		this.nome = nome;
	}

	@Test
	void testSetCrm() {
		this.crm = crm;
	}

	@Test
	void testToString() {
		
	}

}
