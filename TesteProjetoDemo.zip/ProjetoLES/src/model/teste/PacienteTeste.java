package model.teste;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PacienteTeste {

	private Object cpf;
	private Object endereco;
	private Object idade;
	private Object nome;
	private Object id;

	@Test
	void testPaciente() {
		
	}

	@Test
	void testSetId() {
		this.id = id;
	}

	@Test
	void testSetNome() {
		
		this.nome = nome;
	}

	@Test
	void testSetIdade() {
		this.idade = idade;
	}

	@Test
	void testSetEndereco() {
		this.endereco = endereco;
	}

	@Test
	void testSetCpf() {
		this.cpf = cpf;
	}

	@Test
	void testToString() {
		
	}

}
