package model;

public class Laudo {

	private String paciente;
	private String data;
	private String medico;
	private String resultado;
	
	public Laudo() {
		
	}

	public String getPaciente() {
		return paciente;
	}

	public void setPaciente(String paciente) {
		this.paciente = paciente;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getMedico() {
		return medico;
	}

	public void setMedico(String medico) {
		this.medico = medico;
	}

	public String getResultado() {
		return resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}

	@Override
	public String toString() {
		return "Laudo [paciente=" + paciente + ", data=" + data + ", medico=" + medico + ", resultado=" + resultado
				+ "]";
	}
	
	
}
