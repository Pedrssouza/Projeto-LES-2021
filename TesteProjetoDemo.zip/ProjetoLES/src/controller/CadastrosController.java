package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import model.Exame;
import model.Medico;
import model.Paciente;
import model.Professor;
import model.Residente;

public class CadastrosController {

    @FXML private Button btnCadastrarMedico;
    @FXML private Label lblResultadoMedico;
    @FXML private TextField txtIdMedico;
    @FXML private TextField txtNomeMedico;
    @FXML private TextField txtCrmMedico;
    @FXML private Button btnCadastrarResidente;
    @FXML private Label lblResultadoResidente;
    @FXML private TextField txtIdResidente;
    @FXML private TextField txtNomeResidente;
    @FXML private TextField txtCrmResidente;
    @FXML private Button btnCadastrarProfessor;
    @FXML private Label lblResultadoProfessor;
    @FXML private TextField txtIdProfessor;
    @FXML private TextField txtNomeProfessor;
    @FXML private TextField txtCrmProfessor;
    @FXML private Button btnCadastrarPaciente;
    @FXML private TextField txtIdPaciente;
    @FXML private TextField txtNomePaciente;
    @FXML private TextField txtIdade;
    @FXML private TextField txtEndereco;
    @FXML private TextField txtCpf;
    @FXML private Label lblResultadoPaciente;
    @FXML private Label lblResultadoExame;
    @FXML private Button btnCadastrarExame;
    @FXML private TextField txtIdExame;
    @FXML private TextField txtNomeExame;
    @FXML private TextField txtDia;
    @FXML private TextField txtHora;
    
    private Medico medico = new Medico();
    private Residente residente = new Residente();
    private Professor professor = new Professor();
    private Paciente paciente = new Paciente();
    private Exame exame = new Exame();

    @FXML
    void cadastrarExame(ActionEvent event) {

    	exame.setId(Long.parseLong(txtIdExame.getText()));
    	exame.setNomeExame(txtNomeExame.getText());
    	exame.setDia(txtDia.getText());
    	exame.setHora(txtHora.getText());
    	System.out.println(exame.toString());
    }
    @FXML
    void cadastrarMedico(ActionEvent event) {

    	medico.setId(Long.parseLong(txtIdMedico.getText()));
    	medico.setNome(txtNomeMedico.getText());
    	medico.setCrm(txtCrmMedico.getText());   	
    	System.out.println(medico.toString());
    }
    @FXML
    void cadastrarPaciente(ActionEvent event) {

    	paciente.setId(Long.parseLong(txtIdPaciente.getText()));
    	paciente.setNome(txtNomePaciente.getText());
    	paciente.setIdade(txtIdade.getText());
    	paciente.setEndereco(txtEndereco.getText());
    	paciente.setCpf(txtCpf.getText());   	
    	System.out.println(paciente.toString());
    }

    @FXML
    void cadastrarProfessor(ActionEvent event) {

    	professor.setId(Long.parseLong(txtIdProfessor.getText()));
    	professor.setNome(txtNomeProfessor.getText());
    	professor.setCrm(txtCrmProfessor.getText());
    	System.out.println(professor.toString());
    }

    @FXML
    void cadastrarResidente(ActionEvent event) {

    	residente.setId(Long.parseLong(txtIdResidente.getText()));
    	residente.setNome(txtNomeResidente.getText());
    	residente.setCrm(txtCrmResidente.getText());
    	System.out.println(residente.toString());
    }

}
