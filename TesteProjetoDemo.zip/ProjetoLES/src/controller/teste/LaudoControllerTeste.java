package controller.teste;

import static org.junit.Assert.*;

import org.junit.Test;

public class LaudoControllerTeste {

	@Test
	public void testCadastrarLaudo() {
		
	}

}
