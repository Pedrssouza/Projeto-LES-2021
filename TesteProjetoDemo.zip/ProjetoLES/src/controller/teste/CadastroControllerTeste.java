package controller.teste;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CadastroControllerTeste {

	@Test
	void testCadastrarExame() {
		
	}

	@Test
	void testCadastrarMedico() {
		
	}

	@Test
	void testCadastrarPaciente() {
		
	}

	@Test
	void testCadastrarProfessor() {
		
	}

	@Test
	void testCadastrarResidente() {
		
	}

	@Test
	void testObject() {
		
	}

	@Test
	void testGetClass() {
		
	}

	@Test
	void testHashCode() {
		
	}

	@Test
	void testEquals() {
	
	}

	@Test
	void testClone() {
		
	}

	@Test
	void testToString() {
		
	}

	@Test
	void testNotify() {
		
	}

	@Test
	void testNotifyAll() {
		
	}

	@Test
	void testWait() {
		
	}

	@Test
	void testWaitLong() {
		
	}

	@Test
	void testWaitLongInt() {
		
	}

	@Test
	void testFinalize() {
		
	}

}
