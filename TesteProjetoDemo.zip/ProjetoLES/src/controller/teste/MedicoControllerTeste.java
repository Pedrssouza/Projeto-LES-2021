package controller.teste;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MedicoControllerTeste {

	@Test
	void testCadastrarMedico() {
		
	}

	@Test
	void testCadastrarProfessor() {
	}

	@Test
	void testCadastrarResidente() {
		
	}

}
