package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import model.Laudo;

public class LaudoController {

    @FXML
    private TextField txtPaciente;

    @FXML
    private TextField txtData;

    @FXML
    private TextField txtMedico;

    @FXML
    private TextArea txtResultado;

    @FXML
    private Button btnCadastrar;

    @FXML
    private Label lblResultado;
    
    Laudo laudo = new Laudo();

    @FXML
    void cadastrarLaudo(ActionEvent event) {
    	
    	laudo.setPaciente(txtPaciente.getText());
    	laudo.setData(txtData.getText());
    	laudo.setMedico(txtMedico.getText());
    	laudo.setResultado(txtResultado.getText());
    	System.out.println(laudo.toString());
    	
    }

}
