package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import model.Recepcionista;

public class RecepcionistaController {

    @FXML
    private Button btnCadastrar;

    @FXML
    private TextField txtId;

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtCpf;

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtEndereco;
    
    Recepcionista recepcionista = new Recepcionista();

    @FXML
    void CadastrarRecepcionista(ActionEvent event) {

    	recepcionista.setId((Long.parseLong(txtId.getText())));
    	recepcionista.setNome(txtNome.getText());
    	recepcionista.setCpf(txtCpf.getText());
    	recepcionista.setEmail(txtEmail.getText());
    	recepcionista.setEndereco(txtEndereco.getText());
    }

}
