//n�o utilizada

package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class PacienteController {

    @FXML
    private Button btnCadastrarPaciente;

    @FXML
    private TextField txtId;

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtIdade;

    @FXML
    private TextField txtEndereco;

    @FXML
    private TextField txtCpf;

    @FXML
    private Label lblResultado;

    @FXML
    void cadastrarPaciente(ActionEvent event) {

    }

}
