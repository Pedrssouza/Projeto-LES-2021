//n�o utilizada

package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class MedicoController {

    @FXML
    private Button btnCadastrarMedico;

    @FXML
    private Label lblResultadoMedico;

    @FXML
    private TextField txtIdMedico;

    @FXML
    private TextField txtNomeMedico;

    @FXML
    private TextField txtCrmMedico;

    @FXML
    private Button btnCadastrarResidente;

    @FXML
    private Label lblResultadoResidente;

    @FXML
    private TextField txtIdResidente;

    @FXML
    private TextField txtNomeResidente;

    @FXML
    private TextField txtCrmResidente;

    @FXML
    private Button btnCadastrarProfessor;

    @FXML
    private Label lblResultadoProfessor;

    @FXML
    private TextField txtIdProfessor;

    @FXML
    private TextField txtNomeProfessor;

    @FXML
    private TextField txtCrmProfessor;

    @FXML
    void cadastrarMedico(ActionEvent event) {

    }

    @FXML
    void cadastrarProfessor(ActionEvent event) {

    }

    @FXML
    void cadastrarResidente(ActionEvent event) {

    }

}
