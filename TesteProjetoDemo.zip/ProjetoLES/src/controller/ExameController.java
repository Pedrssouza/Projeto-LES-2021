//n�o utilizada

package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import model.Exame;

public class ExameController {

    @FXML
    private TextField txtId;

    @FXML
    private TextField txtTipo;

    @FXML
    private TextField txtDia;

    @FXML
    private TextField txtHora;

    @FXML
    private Button btnCadastrar;

    @FXML
    private Label lblResultado;
    
    Exame exame = new Exame();

    @FXML
    void cadastrarExame(ActionEvent event) {

    	exame.setId(Long.parseLong(txtId.getText()));
    	exame.setNomeExame(txtTipo.getText());
    	exame.setDia(txtDia.getText());
    	exame.setHora(txtHora.getText());
    	System.out.println(exame.toString());
    	
    }

}
